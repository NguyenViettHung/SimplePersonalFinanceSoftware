1. Dòng trên cùng của menu
2. Test case 3 (bỏ qua ảnh vì dữ liệu này cũ)
3. Test case 4
4. Đã sửa
5. Test case 6 --> 2 --> 2026 (dữ liệu cũ, bỏ qua)
6. Test case 6 --> 1 --> 6 --> 2026 (dữ liệu cũ, bỏ qua)
7. File giao\_dich.txt trước và sau khi đóng main
8. file ngan\_sach trước và sau khi bật menu sau đó thoát (case 0)
9. case 3 --> 0 0 0 --> 31 12 9999 --> -1 (với file giao\_dich cũ)
10. Dòng trên cùng menu (mới)
11. (1/2/3/4): case 3 --> 0 0 0 --> 31 12 9999 --> -1
12. (1/2): case 7 --> 2
13. case 5
14. case 8 --> 1 --> 20 --> AnUong

